<script>
    var _zbfpq = _zbfpq || [];
    var cfg = {
        debug: true
        ,filename: '[%Creative%]'
        ,filename_poster: '[%Creativeposter%]'
        ,filename_webm: '[%Creativewebm%]'
        ,filename_ogv: '[%Creativeogv%]'
        ,width: '100%'
        ,height: '100'
        //,headerHeight: '130'
        ,clickTrack: '%%CLICK_URL_UNESC%%[%ClickThroughURL%]'
        ,impressor: '[%ImpressionTrackerURL%]'
    };
    _zbfpq.push(cfg);
    (function() {
        var e = document.createElement('script'); e.type = 'text/javascript'; e.async = true;
        e.src = '%%VIEW_URL_UNESC%%https://media.kurir.rs/banner/amz/js/zbf-pushdown.min5-test.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(e, s);
    })();
</script>

[%ImpressionTrackerScript%]